import java.util.Scanner;

/**
 *
 * @author kukuh adhi pratama
 *         L200174185
 */
public class hitung {
    public static void main(String[] args) {
        Scanner masuk = new Scanner(System.in);
        System.out.println("Tuliskan sebuah kalimat : ");
        String word = masuk.nextLine();
        
        System.out.println("Jumlah karakter = "+word.length());
    }
    
}
