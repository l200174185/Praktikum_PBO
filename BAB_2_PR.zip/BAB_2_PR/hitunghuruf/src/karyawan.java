import java.util.Scanner;

/**
 *
 * @author kukuh adhi pratama
 *         L200174185
 */
public class karyawan {
    // Initialisasi variabel pada java.
    String nm;
    String addr;
    String jab;
    double gaji;
    
    Scanner s = new Scanner(System.in);
    
    void tampilkanNama(){
        System.out.print("Siapa nama anda? ");
        nm = s.nextLine();
    }
    void tampilkanAlamat(){
        System.out.print("Dimana alamat rumah anda? ");
        addr = s.nextLine();
    }
    void tampilkanJabatan(){
        System.out.print("Jabatan anda apa? ");
        jab = s.nextLine();
    }
    void tampilkanGaji(){
        System.out.print("Berapa penghasilan anda?");
        gaji = s.nextDouble();
    }
    void printInfo(){
        System.out.println("\n"+"Nama Anda : "+nm+"\n"+
                "Jabatan Anda : "+jab+"\n"+
                "Alamat rumah anda : "+addr+"\n"+
                "Gaji per bulan : Rp. "+gaji+"\n");
    }
    
    public static void main(String[] args) {
        karyawan sop = new karyawan();
        
        sop.tampilkanNama();
        sop.tampilkanJabatan();
        sop.tampilkanAlamat();
        sop.tampilkanGaji();
        sop.printInfo();
    }
    
    
}
