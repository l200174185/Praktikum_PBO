import java.util.Scanner;

/**
 *
 * @author kukuh adhi pratama
 *         L200174185
 * 
 */
public class mahaSiswa {
    String nm;
    String nim;
    String addr;
    int smt;
    
    Scanner masuk = new Scanner(System.in);
    
    void tampilkanNama(){
        System.out.print("Masukkan Nama Anda ? ");
        nm = masuk.nextLine();
    }
    void tampilkanNim(){
        System.out.print("Masukkan NIM Anda ? ");
        nim = masuk.nextLine();
    }
    void tampilkanAlamat(){
        System.out.print("Dimana rumah anda ? ");
        addr = masuk.nextLine();
    }
    void tampilkanSemester(){
        System.out.print("Semester berapa Anda ? ");
        smt = masuk.nextInt();
        masuk.close();
    }
    void printInfo(){
        System.out.println("\n"+"Nama Anda : "+nm);
        System.out.println("NIM Anda : "+nim);
        System.out.println("Alamat anda : "+addr);
        System.out.println("Anda sedang menempuh semester : "+smt+"\n");
    }
    public static void main(String[] args) {
        mahaSiswa bos = new mahaSiswa();
        bos.tampilkanNama();
        bos.tampilkanNim();
        bos.tampilkanAlamat();
        bos.tampilkanSemester();
        bos.printInfo();
    }   
}