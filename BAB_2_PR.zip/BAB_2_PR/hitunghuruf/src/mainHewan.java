

/**
 *
 * @author kukuh adhi pratama
 *         L200174185
 */
public class mainHewan {
    public static void main(String[] args) {
        // membuat objek untuk memanggil fungsi di kelas tsb
        hewan binatang = new hewan();
        hewan binatang2 = new hewan();
        hewan binatang3 = new hewan();
        
        binatang.namaHe("Harimau");
        binatang.jKaki(4);
        binatang.jMak("Daging");
        binatang.jTipe("Karnivora");
        binatang.printInfo();
        
        binatang2.namaHe("Kerbau");
        binatang2.jKaki(4);
        binatang2.jMak("Rumput");
        binatang2.jTipe("Herbivora");
        binatang2.printInfo();
        
        binatang3.namaHe("Ular");
        binatang3.jKaki(1);
        binatang3.jMak("Daging");
        binatang3.jTipe("Karnivora");
        binatang3.printInfo();
        
    }        
}
