import java.util.Date;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Calendar;
/**
 *
 * @author kukuh adhi pratama
 *         L200174185
 */
public class dosen {
    String nama, edu, op;
    int nik;
    Date si = new Date();
    
    
    Scanner inp = new Scanner(System.in);
    
    void tampilkanNama(){
        System.out.print("Nama Anda ? ");
        nama = inp.nextLine();
    }
    void tampilkanTglLahir(){
        System.out.print("tahun berapa anda lahir ? ");
        op = inp.nextLine();
    }
    void tampilkanNik(){
        System.out.print("Nomor ID Anda ? ");
        nik = inp.nextInt();
        
        inp.close();
    }
            
    void printInfo(){
        System.out.println("\n"+"Nama Anda : "+nama);
        System.out.println("NIK Anda : "+nik);
        System.out.println("Kelahiran Anda : "+si+"\n");
    }
    
    public static void main(String[] args) {
        dosen semangat = new dosen();
        
        semangat.tampilkanNama();
        semangat.tampilkanTglLahir();
        semangat.tampilkanNik();
        semangat.printInfo();
    }
    
}
